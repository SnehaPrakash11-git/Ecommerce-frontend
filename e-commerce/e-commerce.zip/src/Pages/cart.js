import React from "react";
import CartItems from "../Components/CartItems/cartitems";

const Cart = ()=>{
    return(
        <div>
        <CartItems/>
        </div>
    )

}
export default Cart;