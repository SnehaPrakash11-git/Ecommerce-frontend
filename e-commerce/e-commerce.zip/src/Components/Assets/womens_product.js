import p1_img from './p2_img.jfif'
import p2_img from './p3_img.jfif'
import p3_img from './p4_img.jfif'
import p4_img from './p5_img.jfif'



let womens_product = [
    {
        id:1,
        name:"Striped-Flutter-Sleeve-Overlap-Collar-Peplum-Hem-Blouse",
        category:"women",
        image:p1_img,
        new_price:50.00,
        old_price:80.00
    },
    {
        id:2,
        name:"Striped-Flutter-Sleeve-Overlap-Collar-Peplum-Hem-Blouse",
        category:"women",
        image:p2_img,
        new_price:50.00,
        old_price:80.00
    },
    {
        id:3,
        name:"Striped-Flutter-Sleeve-Overlap-Collar-Peplum-Hem-Blouse",
        category:"women",
        image:p3_img,
        new_price:50.00,
        old_price:80.00
    },
    {
        id:4,
        name:"Striped-Flutter-Sleeve-Overlap-Collar-Peplum-Hem-Blouse",
        category:"women",
        image:p4_img,
        new_price:50.00,
        old_price:80.00
    },
    {
        id:5,
        name:"Striped-Flutter-Sleeve-Overlap-Collar-Peplum-Hem-Blouse",
        category:"women",
        image:p1_img,
        new_price:50.00,
        old_price:80.00
    },
    {
        id:6,
        name:"Striped-Flutter-Sleeve-Overlap-Collar-Peplum-Hem-Blouse",
        category:"women",
        image:p2_img,
        new_price:50.00,
        old_price:80.00
    },
    {
        id:7,
        name:"Striped-Flutter-Sleeve-Overlap-Collar-Peplum-Hem-Blouse",
        category:"women",
        image:p3_img,
        new_price:50.00,
        old_price:80.00
    },
    {
        id:8,
        name:"Striped-Flutter-Sleeve-Overlap-Collar-Peplum-Hem-Blouse",
        category:"women",
        image:p4_img,
        new_price:50.00,
        old_price:80.00
    },
    {
        id:9,
        name:"Striped-Flutter-Sleeve-Overlap-Collar-Peplum-Hem-Blouse",
        category:"women",
        image:p4_img,
        new_price:50.00,
        old_price:80.00
    },
    {
        id:10,
        name:"Striped-Flutter-Sleeve-Overlap-Collar-Peplum-Hem-Blouse",
        category:"women",
        image:p4_img,
        new_price:50.00,
        old_price:80.00
    },
]
export default womens_product;
