import p1_img from './mens1.jfif'
import p2_img from './mens2.jfif'
import p3_img from './mens3.jfif'
import p4_img from './mens4.jfif'
import p5_img from "./mens5.jfif"
import p6_img from './mens6.jfif'
import p7_img from './mens7.jfif'
import p8_img from './mens8.jfif'
import p9_img from './mens9.jfif'
import p10_img from "./mens10.jfif"



let mens_product = [
    {
        id:1,
        name:"Model1",
        category:"men",
        image:p1_img,
        new_price:50.00,
        old_price:80.00
    },
    {
        id:2,
        name:"Model2",
        category:"men",
        image:p2_img,
        new_price:50.00,
        old_price:80.00
    },
    {
        id:3,
        name:"Model3",
        category:"men",
        image:p3_img,
        new_price:50.00,
        old_price:80.00
    },
    {
        id:4,
        name:"Model4",
        category:"men",
        image:p4_img,
        new_price:50.00,
        old_price:80.00
    },
    {
        id:5,
        name:"Model4",
        category:"men",
        image:p5_img,
        new_price:50.00,
        old_price:80.00
    },
    {
        id:6,
        name:"Model6",
        category:"men",
        image:p6_img,
        new_price:50.00,
        old_price:80.00
    },
    {
        id:7,
        name:"Model7",
        category:"men",
        image:p7_img,
        new_price:50.00,
        old_price:80.00
    },
    {
        id:8,
        name:"Model8",
        category:"men",
        image:p8_img,
        new_price:50.00,
        old_price:80.00
    },
    {
        id:9,
        name:"Model9",
        category:"men",
        image:p9_img,
        new_price:50.00,
        old_price:80.00
    },
    {
        id:10,
        name:"Model10",
        category:"men",
        image:p10_img,
        new_price:50.00,
        old_price:80.00
    },
]
export default mens_product;
