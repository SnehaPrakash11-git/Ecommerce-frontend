import kids1 from "../Assets/kids1.jfif"
import kids2 from "../Assets/kids2.jfif"
import kids3 from "../Assets/kids3.jfif"
import kids4 from "../Assets/kids4.jfif"
import kids5 from "../Assets/kids5.jfif"
import kids6 from "../Assets/kids6.jfif"
import kids7 from "../Assets/kids7.jfif"
import kids8 from "../Assets/kids8.jfif"




let kids_product = [
    {
        id:1,
        name:"Striped-Flutter-Sleeve-Overlap-Collar-Peplum-Hem-Blouse",
        category:"kids",
        image:kids1,
        new_price:50.00,
        old_price:80.00
    },
    {
        id:2,
        name:"Striped-Flutter-Sleeve-Overlap-Collar-Peplum-Hem-Blouse",
        category:"kids",
        image:kids2,
        new_price:50.00,
        old_price:80.00
    },
    {
        id:3,
        name:"Striped-Flutter-Sleeve-Overlap-Collar-Peplum-Hem-Blouse",
        category:"kids",
        image:kids3,
        new_price:50.00,
        old_price:80.00
    },
    {
        id:4,
        name:"Striped-Flutter-Sleeve-Overlap-Collar-Peplum-Hem-Blouse",
        category:"kids",
        image:kids4,
        new_price:50.00,
        old_price:80.00
    },
    {
        id:5,
        name:"Striped-Flutter-Sleeve-Overlap-Collar-Peplum-Hem-Blouse",
        category:"kids",
        image:kids5,
        new_price:50.00,
        old_price:80.00
    },
    {
        id:6,
        name:"Striped-Flutter-Sleeve-Overlap-Collar-Peplum-Hem-Blouse",
        category:"kids",
        image:kids6,
        new_price:50.00,
        old_price:80.00
    },
    {
        id:7,
        name:"Striped-Flutter-Sleeve-Overlap-Collar-Peplum-Hem-Blouse",
        category:"kids",
        image:kids7,
        new_price:50.00,
        old_price:80.00
    },
    {
        id:8,
        name:"Striped-Flutter-Sleeve-Overlap-Collar-Peplum-Hem-Blouse",
        category:"kids",
        image:kids8,
        new_price:50.00,
        old_price:80.00
    },
]
export default kids_product;
